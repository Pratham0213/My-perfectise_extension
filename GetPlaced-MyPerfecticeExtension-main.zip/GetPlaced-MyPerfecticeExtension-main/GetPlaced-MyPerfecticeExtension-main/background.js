console.log("This is background Script @GETPLACED");
